<?php
$host ="localhost";
$user = "root";
$pass = "";
$db = "db_showroom";

$con = mysqli_connect($host,$user,$pass,$db);
?>
<form method="post">
	<h2 align="center">PT.Maju Bersama Sejahtera</h1>
	<h3 align="center">Showroom Mobil Terpercaya</h3>
	<h4 align="center"> Jalan Raya Tajur KM 67 Bogor Selatan Kota Bogor. FAX: 234445555.EMAIL :Majubersama@gmail.com </h4>
	<hr align="center" size="10" color="black"> 
	<br><br>
	<h3 align="center">Struk Penjualan Mobil</h3>
	<table border="0" align="center">
				
					<?php 
						//perintah sql  
						$sql = "SELECT * FROM tb_showroom WHERE id_pelanggan='$_GET[id]'";
						//mengesekusi perintah diatas
						$query = mysqli_query($con,$sql);
						// untuk menampung data
						$data = mysqli_fetch_array($query);
						//tampil
					 ?>
					<tr>
						<td>Id Pelanggan</td>
						<td>:</td>
						<td><?php echo $data['id_pelanggan']; ?></td>
					</tr>
					<tr>
						<td>Nama </td>
						<td>:</td>
						<td><?php echo $data['nama']; ?></td>
				    </tr>
				    <tr>
						<td>Jenis Kelamin </td>
						<td>: </td>
						<td><?php echo $data['jenis_kelamin']; ?></td>
				    </tr>
				    <tr>
						<td>Merek Kendaraan </td>
						<td>: </td>
						<td><?php echo $data['merek_kendaraan']; ?></td>
					</tr>
					<tr>
						<td>Nama Kendaraan </td>
						<td>: </td>
						<td><?php echo $data['nama_kendaraan']; ?></td>
					</tr>
					<tr>
						<td>Harga Jual </td>
						<td>: </td>
						<td><?php echo $data['hargajual']; ?></td>
					</tr>
					<tr>
					    <td>Jumlah </td>
						<td>: </td>
						<td><?php echo $data['jumlah']; ?></td>
					</tr>
					<tr>
						<td>Total </td>
						<td>: </td>
						<td><?php echo $data['total']; ?></td>
					</td>
					<tr>
						<td>Uang Pelanggan </td>
						<td>: </td>
					    <td><?php echo $data['uang_pelanggan']; ?></td>
 					</tr>
 					<tr>
					    <td>Kembalian </td>
						<td>: </td>
					    <td><?php echo $data['kembalian']; ?></td>
                    </tr>
					   
	</table>
	<br><br><br>
	<p align="center">Terimakasih atas pembelian yang telah anda lakukan</p>
	<p align="center">Mobil Yang telah dibeli tidak dapat ditukar atau di kembalikan</p>
	<br><br>
	<p align="right">Tanda Tangan</p>
	<br><br>
	<p align="right">(__________)</p>
</form>
<script>
	window.onload=function(){
		window.print();
	}
</script>